<?php $__env->startSection('title', 'Masuk Akun — Perpustakaan SMAN 10 Semarang'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth">
    <div class="art">
        <div class="o1"></div>
        <div class="o2"></div>
        <div style="margin-bottom: 24px;">
            <img src="<?php echo e(asset('images/LOGOSMANTEN10.png')); ?>" alt="Logo SMAN 10 Semarang" style="height: 80px; width: auto; object-fit: contain;">
        </div>
        <h1 class="s">Selamat datang kembali!</h1>
        <p>Masuk untuk meminjam buku dan melihat status peminjaman Anda.</p>
    </div>

    <div class="panel">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div>
                <h2 class="s" style="margin-bottom: 4px;">Masuk</h2>
                <div class="muted" style="font-size: 14px;">Gunakan email dan kata sandi terdaftar</div>
            </div>

            <div>
                <label class="label">Email</label>
                <input class="input" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="email@domain.com">
            </div>

            <div>
                <label class="label">Kata Sandi</label>
                <input class="input" type="password" name="password" required placeholder="••••••••">
            </div>

            <button class="btn btn-blue btn-block" type="submit">Masuk</button>

            <div class="muted" style="font-size: 14px; text-align: center;">
                Belum punya akun? <a class="link" href="<?php echo e(route('register')); ?>">Daftar sebagai siswa</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tamu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fahmi/perpustakaan/resources/views/auth/login.blade.php ENDPATH**/ ?>