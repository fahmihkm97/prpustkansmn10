<?php $available = $book->stock > 0; ?>
<div class="book-card"
    data-title="<?php echo e($book->title); ?>" data-author="<?php echo e($book->author); ?>"
    data-cat="<?php echo e($book->category); ?>" data-avail="<?php echo e($available ? 1 : 0); ?>">
    <?php echo $__env->make('partials.sampul-buku', ['title' => $book->title], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="bt"><?php echo e($book->title); ?></div>
    <div class="ba"><?php echo e($book->author); ?></div>
    <span class="badge <?php echo e($available ? 'ok' : 'no'); ?>"><?php echo e($available ? 'Tersedia · ' . $book->stock : 'Habis'); ?></span>
    
    <?php if(($mode ?? 'pinjam') === 'pinjam'): ?>
        <?php if($available): ?>
            <form method="POST" action="<?php echo e(route('siswa.pinjam', $book->id)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-blue btn-sm" style="margin-top:10px;width:100%">Pinjam</button>
            </form>
        <?php else: ?>
            <button type="button" class="btn btn-sm" disabled style="margin-top:10px;width:100%">Stok habis</button>
        <?php endif; ?>
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-blue btn-sm" style="margin-top:10px;width:100%">Masuk untuk pinjam</a>
    <?php endif; ?>
</div><?php /**PATH /home/fahmi/perpustakaan/resources/views/partials/kartu-buku.blade.php ENDPATH**/ ?>