<?php $__env->startSection('title', 'Perpustakaan Digital SMAN 10 Semarang'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $categories = $books->pluck('category')->filter()->unique()->sort()->values();
    $hero = $books->take(3);
?>

<!-- Header Beranda Publik -->
<header class="header-guest">
    <a href="<?php echo e(route('beranda')); ?>" class="logo" style="display:flex; align-items:center; gap:12px; text-decoration:none">
        <img src="<?php echo e(asset('images/LOGOSMANTEN10.png')); ?>" alt="Logo SMAN 10 Semarang" style="height:38px; width:auto; object-fit:contain;">
        <div class="s" style="font-size:16px; font-weight:700;">Perpustakaan SMAN 10 Semarang</div>
    </a>
    
    <!-- Menu Navigasi di Tengah -->
    <nav class="guest-nav">
        <a href="#koleksi" class="nav-pill">Koleksi</a>
        <a href="#cara" class="nav-pill">Cara meminjam</a>
    </nav>

    <!-- Tombol Masuk / Akun -->
    <div>
        <?php if(auth()->guard()->check()): ?>
            <a class="btn btn-blue btn-sm" href="<?php echo e(auth()->user()->role === 'admin' ? route('admin.dashboard') : route('siswa.katalog-buku')); ?>">Buka akun</a>
        <?php else: ?>
            <a class="btn btn-blue btn-sm" href="<?php echo e(route('login')); ?>">Masuk</a>
        <?php endif; ?>
    </div>
</header>

<!-- Hero Section -->
<section class="hero">
    <div class="orb"></div>
    <div style="position:relative">
        <span class="pill">Perpustakaan digital sekolah</span>
        <h1 class="s">Temukan buku favoritmu, pinjam dalam sekejap.</h1>
        <div style="display:flex;gap:10px;max-width:540px;flex-wrap:wrap">
            <input class="input" id="q" style="flex:1;min-width:200px;border-color:#fff" placeholder="Cari judul, penulis, atau kategori">
            <a class="btn" href="#koleksi">Cari buku</a>
        </div>
    </div>
    <?php if($hero->count() === 3): ?>
        <div class="hero-books">
            <?php $__currentLoopData = $hero; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $t = ['rotate(-7deg)', 'translateY(-20px)', 'rotate(7deg)'][$i]; ?>
                <div style="transform:<?php echo e($t); ?>"><?php echo $__env->make('partials.sampul-buku', ['title' => $b->title], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>

<!-- Filter Kategori Chip -->
<?php if($categories->isNotEmpty()): ?>
    <div class="px" style="display:flex;gap:12px;padding-top:28px;padding-bottom:8px;flex-wrap:wrap">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="chip c<?php echo e($i % 5); ?>" data-cat="<?php echo e($cat); ?>"><?php echo e($cat); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<!-- Daftar Koleksi Buku -->
<section id="koleksi" class="px" style="padding-top:20px;padding-bottom:44px">
    <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:18px;flex-wrap:wrap;gap:8px">
        <h2 class="s" style="font-size:28px">Koleksi buku</h2>
        <span id="count" class="ba"></span>
    </div>

    <div class="grid-books five">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.kartu-buku', ['book' => $book, 'mode' => 'login'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div id="no-result" class="empty" style="<?php echo e($books->isEmpty() ? '' : 'display:none'); ?>">Belum ada buku yang cocok.</div>
</section>

<!-- Panduan Cara Meminjam -->
<section id="cara" class="steps">
    <div class="step"><div class="n">1</div><b>Cari buku</b></div>
    <div class="step"><div class="n">2</div><b>Pesan lewat ponsel</b></div>
    <div class="step"><div class="n">3</div><b>Ambil di perpustakaan</b></div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/catalog.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.tamu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fahmi/perpustakaan/resources/views/beranda.blade.php ENDPATH**/ ?>