<?php $__env->startSection('title', 'Katalog Buku'); ?>

<?php $__env->startSection('content'); ?>
<?php $categories = $books->pluck('category')->filter()->unique()->sort()->values(); ?>

<h1 class="s" style="font-size:36px;margin-bottom:20px">Katalog buku</h1>
<input class="input" id="q" style="max-width:640px;margin-bottom:28px" placeholder="Cari judul, penulis, atau kategori">

<div class="cat-layout" style="display:grid;grid-template-columns:220px 1fr;gap:32px">
    <aside class="cd" style="padding:22px;align-self:start">
        <div class="s" style="font-size:18px;margin-bottom:8px">Kategori</div>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <label class="cat-box"><input type="checkbox" class="f-cat" value="<?php echo e($cat); ?>"><?php echo e($cat); ?></label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="ba">Belum ada kategori</div>
        <?php endif; ?>

        <div class="s" style="font-size:18px;margin:20px 0 8px">Ketersediaan</div>
        <label class="cat-box"><input type="checkbox" id="f-avail">Hanya yang tersedia</label>
    </aside>

    <div>
        <div style="display:flex;justify-content:space-between;margin-bottom:18px;font-size:14px">
            <span class="ba" id="count">Menampilkan <?php echo e($books->count()); ?> buku</span>
        </div>
        <div class="grid-books">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.kartu-buku', ['book' => $book, 'mode' => 'pinjam'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div id="no-result" class="empty" style="<?php echo e($books->isEmpty() ? '' : 'display:none'); ?>">Tidak ada buku yang cocok.</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/catalog.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fahmi/perpustakaan/resources/views/siswa/katalog-buku.blade.php ENDPATH**/ ?>