<?php
    $hasImage = !empty($cover_image ?? $book->cover_image ?? null);
    $imgPath = $hasImage ? asset('storage/' . ($cover_image ?? $book->cover_image)) : null;

    $palette = [
        ['#10B981', '#FFC93C', '#fff'],
        ['#1D4ED8', '#FF6B5B', '#fff'],
        ['#FFC93C', '#1D4ED8', '#0F1B3D'],
        ['#FF6B5B', '#FFE08A', '#0F1B3D'],
        ['#7C3AED', '#10B981', '#fff'],
        ['#0EA5E9', '#FFC93C', '#0F1B3D'],
        ['#065F46', '#FFC93C', '#fff'],
        ['#B45309', '#FFE08A', '#fff'],
    ];
    $p = $palette[crc32($title ?? 'Buku') % count($palette)];
?>

<?php if($hasImage): ?>
    <div class="bk <?php echo e($class ?? ''); ?>" style="padding:0;background:#000;">
        <img src="<?php echo e($imgPath); ?>" alt="<?php echo e($title ?? 'Sampul Buku'); ?>" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;">
    </div>
<?php else: ?>
    <div class="bk <?php echo e($class ?? ''); ?>" style="background:<?php echo e($p[0]); ?>;--c2:<?php echo e($p[1]); ?>;color:<?php echo e($p[2]); ?>"><?php echo e($title ?? ''); ?></div>
<?php endif; ?><?php /**PATH /home/fahmi/perpustakaan/resources/views/partials/sampul-buku.blade.php ENDPATH**/ ?>