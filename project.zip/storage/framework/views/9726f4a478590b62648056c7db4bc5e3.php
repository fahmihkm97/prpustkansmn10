<?php $__env->startSection('title', 'Riwayat Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:760px;margin:0 auto">
    <h1 class="s" style="font-size:32px;margin-bottom:14px">Riwayat pinjaman</h1>

    <div class="tabs" style="font-size:13px">
        <a class="tab" href="<?php echo e(route('siswa.peminjaman')); ?>">Aktif</a>
        <span class="tab on">Selesai</span>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $title = $r->buku->title ?? 'Buku'; ?>
        <div class="loan" style="border-radius:18px">
            <?php echo $__env->make('partials.book-cover', ['title' => $title, 'class' => 'bk-sm'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="info-col">
                <b style="font-size:15px"><?php echo e($title); ?></b>
                <div class="ba">Kode: <b><?php echo e($r->trx_code); ?></b></div>
                <div class="ba">Dikembalikan <?php echo e($r->returned_at ? \Carbon\Carbon::parse($r->returned_at)->format('d M Y') : '-'); ?></div>
                <span class="badge ok" style="margin-top:6px">Selesai</span>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="cd empty" style="padding:48px 22px">Belum ada buku yang dikembalikan.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fahmi/perpustakaan/resources/views/siswa/riwayat-pengembalian.blade.php ENDPATH**/ ?>